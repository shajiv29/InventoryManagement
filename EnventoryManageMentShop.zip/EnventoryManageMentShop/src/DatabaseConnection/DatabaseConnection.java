package DatabaseConnection;

import java.sql.*;

public class DatabaseConnection {

    Connection con = null;

    public static Connection ConnectDB() {
        try {
           
            Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/Sumite", "root", "123456");
            return con;

        } catch (SQLException ex) {

            return null;
        }
        

    }
}
